﻿using System;
using VersOne.Epub;

namespace ejercicio3
{
    static class LeerEPUB
    {
        static void RecorrerEPUB(EpubBookRef archivoEPUB, bool imprimirArchivo)
        {
            using (archivoEPUB)
            {
                ImprimirInformacion(archivoEPUB);

                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("Tabla de contenidos");
                Console.ResetColor();

                foreach (EpubNavigationItemRef contenido in archivoEPUB.GetNavigation())
                {
                    ImprimirContenido(contenido, 0, imprimirArchivo);
                }
            }
            Console.WriteLine();
        }

        static void ImprimirInformacion(EpubBookRef archivoEPUB)
        {
            if (archivoEPUB != null)
            {
                // Imprimir título del libro
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Título del libro: ");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(archivoEPUB.Title);

                // Imprimir descripción (si existe)
                String description = archivoEPUB.Description;
                if (!description.Contains("<c>null"))
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Descripción:");
                    Console.ResetColor();
                    Console.WriteLine(ParsearTexto(archivoEPUB.Description));
                }

                // Imprimir autor o autores
                if (archivoEPUB.AuthorList.Count > 1)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Autores:");
                    Console.ResetColor();
                    foreach (string autor in archivoEPUB.AuthorList)
                    {
                        Console.WriteLine(autor);
                    }
                } else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("Autor/a: ");
                    Console.ResetColor();
                    Console.WriteLine(archivoEPUB.Author);
                }
            }
        }

        // Elimina las etiquetas HTML para dejar sólo el texto
        private static string ParsearTexto(string texto)
        {
            string result = "";
            bool escribir = false;
            for (int i=0; i < texto.Length; i++)
            {
                if (texto[i] == '<')
                {
                    escribir = false;
                } else if (texto[i] == '>')
                {
                    escribir = true;
                } else
                {
                    if (escribir)
                    {
                        result += texto[i];
                    }
                }
            }
            return result;
        } 

        static void ImprimirContenido(EpubNavigationItemRef contenido, int nivel, bool imprimirArchivo)
        {
            for (int i=0; i<nivel; i++)
            {
                Console.Write('\t'); // (subcontenido) añade una tabulacion por cada nivel
            }

            // Imprime el título del elemento de la tabla de contenidos
            Console.Write(contenido.Title);

            if (imprimirArchivo)
            {
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine("\t{" + contenido.HtmlContentFileRef.FileName + "}");
                Console.ResetColor();
            } else
            {
                Console.WriteLine();
            }

            // Si el contenido tiene subcontenidos, los imprime
            foreach (EpubNavigationItemRef subcontenido in contenido.NestedItems)
            {
                ImprimirContenido(subcontenido, nivel + 1, imprimirArchivo);
            }
        }

        static void Main()
        {
            while (true)
            {
                Console.WriteLine("Introduce la ruta del EPUB:");
                string ruta = Console.ReadLine();
                EpubBookRef epub = EpubReader.OpenBook(ruta);

                Console.WriteLine("¿Quieres ver el archivo de cada capítulo? [Y|N]");
                string option = Console.ReadLine();
                bool op = false;
                if (option[0] == 'Y' || option[0] == 'y')
                {
                    op = true;
                }

                RecorrerEPUB(epub, op);

                Console.WriteLine();
                Console.WriteLine("¿Quieres consultar otro EPUB? [Y|N]");
                option = Console.ReadLine();
                if (option[0] == 'N' || option[0] == 'n')
                {
                    break;
                }
            }
        }
    }
}